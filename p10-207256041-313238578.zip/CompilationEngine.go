package main

import (
	"fmt"
	"os"
)

var tab = 0

type CompilationEngine struct {
	jt         *JackTokenizer
	outputFile *os.File
}

func CreateCompilationEngine(inputFile *os.File, outputFile *os.File) *CompilationEngine {
	cEngine := &CompilationEngine{CreateTokenizer(inputFile), outputFile}
	return cEngine
}
func (cEngine *CompilationEngine) CompileClass() {
	cEngine.checkToken("class")
	cEngine.outputFile.WriteString("<class>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> class </keyword>\n")
	cEngine.jt.Advance()
	cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	cEngine.jt.Advance()
	cEngine.checkToken("{")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> { </symbol>\n")
	cEngine.jt.Advance()

	//check for field or static variables
	for cEngine.jt.CurrentToken() == "field" || cEngine.jt.CurrentToken() == "static" {
		cEngine.CompileClassVarDec()
	}

	//check for subroutines
	for cEngine.jt.CurrentToken() == "constructor" || cEngine.jt.CurrentToken() == "function" || cEngine.jt.CurrentToken() == "method" {
		cEngine.CompileSubroutine()
	}

	cEngine.checkToken("}")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> } </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</class>\n")
}

func (cEngine *CompilationEngine) CompileClassVarDec() {
	cEngine.outputFile.WriteString(tabber(tab) + "<classVarDec>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.CurrentToken() + " </keyword>\n")
	cEngine.jt.Advance()                   // type
	if cEngine.jt.TokenType() == KEYWORD { // primitive type
		cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.CurrentToken() + " </keyword>\n")
	} else { // class type
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	}
	cEngine.jt.Advance() // name
	cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	cEngine.jt.Advance()

	// check for more variables of same type in this line
	for cEngine.jt.CurrentToken() != ";" {
		cEngine.checkToken(",")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> , </symbol>\n")
		cEngine.writeVar()
	}
	cEngine.checkToken(";")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	cEngine.jt.Advance()
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</classVarDec>\n")
}

func (cEngine *CompilationEngine) CompileSubroutine() {
	cEngine.outputFile.WriteString(tabber(tab) + "<subroutineDec>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.CurrentToken() + " </keyword>\n")
	switch cEngine.jt.CurrentToken() {
	case "constructor":
		{
			cEngine.jt.Advance()
			cEngine.checkTokenType("identifier")
			cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
			cEngine.jt.Advance() // "new"
			cEngine.checkToken("new")
			cEngine.outputFile.WriteString(tabber(tab) + "<identifier> new </identifier>\n")
		}
	case "method", "function":
		{
			cEngine.jt.Advance()
			cEngine.checkTokenType("keyword")
			cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.CurrentToken() + " </keyword>\n")
			cEngine.jt.Advance() // method/function name
			cEngine.checkTokenType("identifier")
			cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
		}
	}

	cEngine.jt.Advance() // "("
	cEngine.checkToken("(")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ( </symbol>\n")
	cEngine.jt.Advance()

	// check for parameters
	cEngine.outputFile.WriteString(tabber(tab) + "<parameterList>\n")
	tab++
	cEngine.CompileParameterList()
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</parameterList>\n")
	cEngine.checkToken(")")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ) </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileSubroutineBody()
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</subroutineDec>\n")
}

func (cEngine *CompilationEngine) CompileSubroutineBody() {
	cEngine.checkToken("{")
	cEngine.outputFile.WriteString(tabber(tab) + "<subroutineBody>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> { </symbol>\n")

	cEngine.jt.Advance()
	//check for var decs
	for cEngine.jt.CurrentToken() == "var" {
		cEngine.CompileVarDec()
	}

	//check for statements
	if cEngine.isStatement(cEngine.jt.CurrentToken()) {
		cEngine.CompileStatements()
	}
	cEngine.checkToken("}")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> } </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</subroutineBody>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileParameterList() {
	for cEngine.jt.TokenType() == KEYWORD {
		cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.KeyWord() + " </keyword>\n")
		cEngine.jt.Advance() // parameter name
		cEngine.checkTokenType("identifier")
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
		cEngine.jt.Advance() // , or )

		//check for more parameters
		if cEngine.jt.CurrentToken() == "," {
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> , </symbol>\n")
			cEngine.jt.Advance()
			cEngine.CompileParameterList()
		}
	}
}

func (cEngine *CompilationEngine) CompileVarDec() {
	cEngine.outputFile.WriteString(tabber(tab) + "<varDec>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> var </keyword>\n")
	cEngine.jt.Advance()                   // var type
	if cEngine.jt.TokenType() == KEYWORD { //primitive type
		cEngine.outputFile.WriteString(tabber(tab) + "<keyword> " + cEngine.jt.CurrentToken() + " </keyword>\n")
	} else { // class type
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	}
	cEngine.jt.Advance() //var name
	cEngine.checkTokenType(IDENTIFIER)
	cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	cEngine.jt.Advance() // , or ;
	for cEngine.jt.CurrentToken() == "," {
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> , </symbol>\n")
		cEngine.writeVar()
	}
	cEngine.checkToken(";")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</varDec>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileStatements() {
	cEngine.outputFile.WriteString(tabber(tab) + "<statements>\n")
	tab++
	for cEngine.isStatement(cEngine.jt.CurrentToken()) {
		switch cEngine.jt.CurrentToken() {
		case "let":
			{
				cEngine.CompileLet()
			}
		case "if":
			{
				cEngine.CompileIf()
			}
		case "while":
			{
				cEngine.CompileWhile()
			}
		case "do":
			{
				cEngine.CompileDo()
			}
		case "return":
			{
				cEngine.CompileReturn()
			}
		}
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</statements>\n")
}

func (cEngine *CompilationEngine) CompileLet() {
	cEngine.outputFile.WriteString(tabber(tab) + "<letStatement>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> let </keyword>\n")
	cEngine.jt.Advance() // var name
	cEngine.checkTokenType("identifier")
	cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	cEngine.jt.Advance() // "[" or "="
	if cEngine.jt.CurrentToken() == "[" {
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> [ </symbol>\n")
		cEngine.jt.Advance()
		cEngine.CompileExpression()
		cEngine.checkToken("]")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ] </symbol>\n")
		cEngine.jt.Advance()
	}
	if cEngine.jt.CurrentToken() == "=" {
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> = </symbol>\n")
		cEngine.jt.Advance()
		cEngine.CompileExpression()
	}
	cEngine.checkToken(";")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</letStatement>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileIf() {
	cEngine.outputFile.WriteString(tabber(tab) + "<ifStatement>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> if </keyword>\n")
	cEngine.jt.Advance()
	cEngine.checkToken("(")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ( </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileExpression()
	cEngine.checkToken(")")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ) </symbol>\n")
	cEngine.jt.Advance()
	cEngine.checkToken("{")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> { </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileStatements()
	cEngine.checkToken("}")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> } </symbol>\n")
	cEngine.jt.Advance() // else?
	if cEngine.jt.CurrentToken() == "else" {
		cEngine.outputFile.WriteString(tabber(tab) + "<keyword> else </keyword>\n")
		cEngine.jt.Advance()
		cEngine.checkToken("{")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> { </symbol>\n")
		cEngine.jt.Advance()
		cEngine.CompileStatements()
		cEngine.checkToken("}")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> } </symbol>\n")
		cEngine.jt.Advance()
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</ifStatement>\n")
}

func (cEngine *CompilationEngine) CompileWhile() {
	cEngine.outputFile.WriteString(tabber(tab) + "<whileStatement>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> while </keyword>\n")
	cEngine.jt.Advance() // "("
	cEngine.checkToken("(")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ( </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileExpression()
	cEngine.checkToken(")")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ) </symbol>\n")
	cEngine.jt.Advance() // "{"
	cEngine.checkToken("{")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> { </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileStatements()
	cEngine.checkToken("}")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> } </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</whileStatement>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileDo() {
	cEngine.outputFile.WriteString(tabber(tab) + "<doStatement>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> do </keyword>\n")
	cEngine.jt.Advance() // subroutineName or className/varName
	cEngine.checkTokenType("identifier")
	cEngine.CompileSubroutineCall()
	cEngine.checkToken(";")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</doStatement>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileReturn() {
	cEngine.outputFile.WriteString(tabber(tab) + "<returnStatement>\n")
	tab++
	cEngine.outputFile.WriteString(tabber(tab) + "<keyword> return </keyword>\n")
	cEngine.jt.Advance() // ; or experssion
	if cEngine.jt.CurrentToken() == ";" {
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	} else {
		cEngine.CompileExpression()
		cEngine.checkToken(";")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ; </symbol>\n")
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</returnStatement>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileExpression() {
	cEngine.outputFile.WriteString(tabber(tab) + "<expression>\n")
	tab++
	cEngine.CompileTerm()
	for cEngine.isOp(cEngine.jt.CurrentToken()) {
		cEngine.CompileOp()
		cEngine.CompileTerm()
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</expression>\n")
}

func (cEngine *CompilationEngine) CompileTerm() {
	cEngine.outputFile.WriteString(tabber(tab) + "<term>\n")
	tab++
	if cEngine.jt.CurrentToken() == "~" || cEngine.jt.CurrentToken() == "-" { //unaryOp term
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> " + cEngine.jt.CurrentToken() + " </symbol>\n")
		cEngine.jt.Advance()
		cEngine.CompileTerm()
	} else if cEngine.jt.TokenType() == STRING_CONST ||
		cEngine.jt.TokenType() == INT_CONST ||
		cEngine.jt.TokenType() == KEYWORD { //constant
		cEngine.outputFile.WriteString(tabber(tab) + "<" + cEngine.jt.TokenType() + "> " + cEngine.jt.CurrentToken() + " </" + cEngine.jt.TokenType() + ">\n")
		cEngine.jt.Advance()
	} else if cEngine.jt.TokenType() == "identifier" { //varName
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
		cEngine.jt.Advance()
		if cEngine.jt.CurrentToken() == "(" || cEngine.jt.CurrentToken() == "." { // subroutineCall
			cEngine.CompileSubroutineCall()
		} else if cEngine.jt.CurrentToken() == "[" { // varName [experssion]
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> [ </symbol>\n")
			cEngine.jt.Advance()
			cEngine.CompileExpression()
			cEngine.checkToken("]")
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ] </symbol>\n")
			cEngine.jt.Advance()
		}
	} else if cEngine.jt.CurrentToken() == "(" { // (expressionList)
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ( </symbol>\n")
		cEngine.jt.Advance()
		cEngine.CompileExpression()
		cEngine.checkToken(")")
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ) </symbol>\n")
		cEngine.jt.Advance()
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</term>\n")
}

func (cEngine *CompilationEngine) CompileExpressionList() int {
	cEngine.outputFile.WriteString(tabber(tab) + "<expressionList>\n")
	tab++
	sum := 0
	if cEngine.jt.CurrentToken() != ")" { // no more experssions
		cEngine.CompileExpression()
		for cEngine.jt.CurrentToken() == "," {
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> , </symbol>\n")
			cEngine.jt.Advance()
			cEngine.CompileExpression()
		}
	}
	tab--
	cEngine.outputFile.WriteString(tabber(tab) + "</expressionList>\n")
	return sum
}

func (cEngine *CompilationEngine) CompileSubroutineCall() {
	if cEngine.jt.TokenType() == IDENTIFIER {
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
		cEngine.jt.Advance() // "." or subroutineName
	}
	if cEngine.jt.CurrentToken() == "." {
		cEngine.outputFile.WriteString(tabber(tab) + "<symbol> . </symbol>\n")
		cEngine.jt.Advance() // subrountineName
		cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
		cEngine.jt.Advance()
	}
	cEngine.checkToken("(")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ( </symbol>\n")
	cEngine.jt.Advance()
	cEngine.CompileExpressionList()
	cEngine.checkToken(")")
	cEngine.outputFile.WriteString(tabber(tab) + "<symbol> ) </symbol>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) CompileOp() {
	switch cEngine.jt.CurrentToken() {
	case "+":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> + </symbol>\n")
		}
	case "-":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> - </symbol>\n")
		}
	case "*":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> * </symbol>\n")
		}
	case "/":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> / </symbol>\n")
		}
	case "&":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> &amp; </symbol>\n")
		}
	case "|":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> | </symbol>\n")
		}
	case "<":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> &lt; </symbol>\n")
		}
	case ">":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> &gt; </symbol>\n")
		}
	case "=":
		{
			cEngine.outputFile.WriteString(tabber(tab) + "<symbol> = </symbol>\n")
		}
	}
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) writeVar() {
	cEngine.jt.Advance() // variable name
	cEngine.checkTokenType(IDENTIFIER)
	cEngine.outputFile.WriteString(tabber(tab) + "<identifier> " + cEngine.jt.CurrentToken() + " </identifier>\n")
	cEngine.jt.Advance()
}

func (cEngine *CompilationEngine) checkToken(token string) {
	if cEngine.jt.CurrentToken() != token {
		fmt.Println("compilation error - expected " + token + " but recevied " + cEngine.jt.CurrentToken())
		panic(1)
	}
}

func (cEngine *CompilationEngine) checkTokenType(tokenType string) {
	if cEngine.jt.TokenType() != tokenType {
		fmt.Println("compilation error - expected type " + tokenType + " but recevied " + cEngine.jt.CurrentToken())
		panic(1)
	}
}

func (cEngine *CompilationEngine) isOp(token string) bool {
	if token == "+" ||
		token == "-" ||
		token == "*" ||
		token == "/" ||
		token == "&" ||
		token == "|" ||
		token == "<" ||
		token == ">" ||
		token == "=" {
		return true
	}
	return false
}

func (cEngine *CompilationEngine) isStatement(token string) bool {
	if cEngine.jt.CurrentToken() == "let" ||
		cEngine.jt.CurrentToken() == "if" ||
		cEngine.jt.CurrentToken() == "while" ||
		cEngine.jt.CurrentToken() == "do" ||
		cEngine.jt.CurrentToken() == "return" {
		return true
	}
	return false
}

func tabber(num int) string {
	tabber := ""
	for i := 0; i < num; i++ {
		tabber += "  "
	}
	return tabber
}
